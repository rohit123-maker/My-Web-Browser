/**
 * @file Main Browser Application Component
 * @description Enhanced Web Browser PWA with bookmarks, settings, and history
 */

import React, { useState, useRef, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { ArrowLeft, ArrowRight, RefreshCw, Plus, X, Home as HomeIcon, Star, BookmarkPlus } from 'lucide-react';
import { useBrowserStorage } from '../hooks/useBrowserStorage';
import { BookmarksBar } from '../components/BookmarksBar';
import { SettingsModal } from '../components/SettingsModal';
import { BrowserTab } from '../types/browser';

export default function Home() {
  const {
    data,
    isLoaded,
    addBookmark,
    removeBookmark,
    addHistory,
    clearHistory,
    updateSettings,
    applyTheme
  } = useBrowserStorage();

  const [tabs, setTabs] = useState<BrowserTab[]>([
    { id: '1', title: 'New Tab', url: data.settings.homePage, isLoading: false }
  ]);
  const [activeTab, setActiveTab] = useState('1');
  const [urlInput, setUrlInput] = useState('');
  const [showBookmarkDialog, setShowBookmarkDialog] = useState(false);
  const [currentBookmarkTitle, setCurrentBookmarkTitle] = useState('');
  const iframeRef = useRef<HTMLIFrameElement>(null);

  /**
   * Apply theme when settings change
   */
  useEffect(() => {
    if (isLoaded) {
      applyTheme(data.settings.theme);
    }
  }, [data.settings.theme, isLoaded, applyTheme]);

  /**
   * Update homepage when settings change
   */
  useEffect(() => {
    if (isLoaded && tabs.length > 0) {
      setTabs(prev => prev.map(tab => 
        tab.id === activeTab ? { ...tab, url: data.settings.homePage } : tab
      ));
      setUrlInput(data.settings.homePage);
    }
  }, [data.settings.homePage, isLoaded]);

  /**
   * Add a new browser tab
   */
  const addNewTab = () => {
    const newTabId = Date.now().toString();
    const newTab: BrowserTab = {
      id: newTabId,
      title: 'New Tab',
      url: 'about:blank',
      isLoading: false
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTab(newTabId);
    setUrlInput('');
  };

  /**
   * Close a browser tab
   */
  const closeTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return; // Don't close the last tab
    
    const newTabs = tabs.filter(tab => tab.id !== tabId);
    setTabs(newTabs);
    
    if (activeTab === tabId) {
      setActiveTab(newTabs[0].id);
      setUrlInput(newTabs[0].url);
    }
  };

  /**
   * Navigate to a URL
   */
  const navigateToUrl = (url: string) => {
    if (!url) return;
    
    let finalUrl = url;
    if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('about:')) {
      if (url.includes('.') && !url.includes(' ')) {
        finalUrl = `https://${url}`;
      } else {
        const searchUrl = data.settings.searchEngine === 'bing' 
          ? `https://www.bing.com/search?q=${encodeURIComponent(url)}`
          : data.settings.searchEngine === 'duckduckgo'
          ? `https://duckduckgo.com/?q=${encodeURIComponent(url)}`
          : `https://www.google.com/search?q=${encodeURIComponent(url)}`;
        finalUrl = searchUrl;
      }
    }

    setTabs(prev => prev.map(tab => 
      tab.id === activeTab ? { ...tab, url: finalUrl, isLoading: true } : tab
    ));
    setUrlInput(finalUrl);
  };

  /**
   * Handle URL input submission
   */
  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigateToUrl(urlInput);
  };

  /**
   * Handle iframe load event
   */
  const handleIframeLoad = (tabId: string) => {
    const tab = tabs.find(t => t.id === tabId);
    if (tab && tab.url !== 'about:blank') {
      // Add to history
      addHistory(tab.title, tab.url);
    }
    
    setTabs(prev => prev.map(tab => 
      tab.id === tabId ? { ...tab, isLoading: false } : tab
    ));
  };

  /**
   * Navigate back in history
   */
  const goBack = () => {
    if (iframeRef.current) {
      try {
        iframeRef.current.contentWindow?.history.back();
      } catch (error) {
        console.log('Cannot navigate back');
      }
    }
  };

  /**
   * Navigate forward in history
   */
  const goForward = () => {
    if (iframeRef.current) {
      try {
        iframeRef.current.contentWindow?.history.forward();
      } catch (error) {
        console.log('Cannot navigate forward');
      }
    }
  };

  /**
   * Refresh current page
   */
  const refreshPage = () => {
    if (iframeRef.current) {
      iframeRef.current.src = iframeRef.current.src;
      setTabs(prev => prev.map(tab => 
        tab.id === activeTab ? { ...tab, isLoading: true } : tab
      ));
    }
  };

  /**
   * Go to home page
   */
  const goHome = () => {
    navigateToUrl(data.settings.homePage);
  };

  /**
   * Check if current page is bookmarked
   */
  const isCurrentPageBookmarked = () => {
    const activeTabData = tabs.find(tab => tab.id === activeTab);
    return activeTabData ? data.bookmarks.some(bookmark => bookmark.url === activeTabData.url) : false;
  };

  /**
   * Add current page to bookmarks
   */
  const addCurrentPageToBookmarks = () => {
    const activeTabData = tabs.find(tab => tab.id === activeTab);
    if (activeTabData && activeTabData.url !== 'about:blank') {
      if (isCurrentPageBookmarked()) {
        // Remove if already bookmarked
        const bookmark = data.bookmarks.find(b => b.url === activeTabData.url);
        if (bookmark) removeBookmark(bookmark.id);
      } else {
        // Add new bookmark
        setCurrentBookmarkTitle(activeTabData.title);
        setShowBookmarkDialog(true);
      }
    }
  };

  /**
   * Confirm bookmark addition
   */
  const confirmBookmark = () => {
    const activeTabData = tabs.find(tab => tab.id === activeTab);
    if (activeTabData) {
      addBookmark({
        title: currentBookmarkTitle || activeTabData.title,
        url: activeTabData.url
      });
      setShowBookmarkDialog(false);
      setCurrentBookmarkTitle('');
    }
  };

  const activeTabData = tabs.find(tab => tab.id === activeTab);

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Browser Controls */}
      <div className="bg-white border-b border-gray-200 p-2 dark:bg-gray-900 dark:border-gray-700">
        <div className="flex items-center gap-2 mb-2">
          {/* Navigation Controls */}
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" onClick={goBack} className="bg-transparent h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={goForward} className="bg-transparent h-8 w-8">
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={refreshPage} className="bg-transparent h-8 w-8">
              <RefreshCw className={`h-4 w-4 ${activeTabData?.isLoading ? 'animate-spin' : ''}`} />
            </Button>
            <Button variant="outline" size="icon" onClick={goHome} className="bg-transparent h-8 w-8">
              <HomeIcon className="h-4 w-4" />
            </Button>
          </div>

          {/* URL Bar */}
          <form onSubmit={handleUrlSubmit} className="flex-1 flex gap-2">
            <Input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder={`Search with ${data.settings.searchEngine} or enter website address`}
              className="flex-1"
            />
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
              Go
            </Button>
          </form>

          {/* Action Buttons */}
          <div className="flex items-center gap-1">
            {/* Bookmark Button */}
            {activeTabData && activeTabData.url !== 'about:blank' && (
              <Button
                variant="outline"
                size="icon"
                onClick={addCurrentPageToBookmarks}
                className={`bg-transparent h-8 w-8 ${
                  isCurrentPageBookmarked() ? 'text-yellow-500 fill-yellow-500' : ''
                }`}
              >
                <Star className={`h-4 w-4 ${isCurrentPageBookmarked() ? 'fill-current' : ''}`} />
              </Button>
            )}

            {/* New Tab Button */}
            <Button variant="outline" size="icon" onClick={addNewTab} className="bg-transparent h-8 w-8">
              <Plus className="h-4 w-4" />
            </Button>

            {/* Settings Button */}
            <SettingsModal
              settings={data.settings}
              bookmarks={data.bookmarks}
              history={data.history}
              onSettingsUpdate={updateSettings}
              onBookmarkRemove={removeBookmark}
              onHistoryClear={clearHistory}
              onBookmarkClick={navigateToUrl}
            />
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-1 overflow-x-auto">
          {tabs.map((tab) => (
            <div
              key={tab.id}
              className={`flex items-center gap-2 px-3 py-2 rounded-t-lg border cursor-pointer min-w-0 max-w-48 ${
                activeTab === tab.id
                  ? 'bg-white border-b-white border-gray-300 dark:bg-gray-800 dark:border-gray-600'
                  : 'bg-gray-100 border-transparent hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600'
              }`}
              onClick={() => {
                setActiveTab(tab.id);
                setUrlInput(tab.url);
              }}
            >
              <span className="truncate flex-1 text-sm">{tab.title}</span>
              {tabs.length > 1 && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => closeTab(tab.id, e)}
                  className="h-4 w-4 bg-transparent hover:bg-gray-300 dark:hover:bg-gray-500"
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Bookmarks Bar */}
      <BookmarksBar
        bookmarks={data.bookmarks}
        onBookmarkClick={navigateToUrl}
        visible={data.settings.showBookmarksBar}
      />

      {/* Bookmark Dialog */}
      {showBookmarkDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4 dark:text-white">Add Bookmark</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2 dark:text-gray-300">Title</label>
                <Input
                  value={currentBookmarkTitle}
                  onChange={(e) => setCurrentBookmarkTitle(e.target.value)}
                  placeholder="Bookmark title"
                  className="w-full"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setShowBookmarkDialog(false)} className="bg-transparent">
                  Cancel
                </Button>
                <Button onClick={confirmBookmark} className="bg-blue-600 hover:bg-blue-700 text-white">
                  <BookmarkPlus className="h-4 w-4 mr-2" />
                  Add Bookmark
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Browser Content */}
      <div className="flex-1 bg-white dark:bg-gray-900">
        {tabs.map((tab) => (
          <div
            key={tab.id}
            className={`h-full w-full ${activeTab === tab.id ? 'block' : 'hidden'}`}
          >
            <iframe
              ref={activeTab === tab.id ? iframeRef : null}
              src={tab.url}
              className="w-full h-full border-0"
              title={tab.title}
              onLoad={() => handleIframeLoad(tab.id)}
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            />
          </div>
        ))}
      </div>

      {/* Status Bar */}
      <div className="bg-gray-100 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-3 py-1 text-xs text-gray-600 dark:text-gray-400">
        {activeTabData?.isLoading ? 'Loading...' : 'Ready'}
      </div>
    </div>
  );
}

/**
 * @file Browser Type Definitions
 * @description TypeScript interfaces for browser data structures
 */

export interface BrowserTab {
  id: string;
  title: string;
  url: string;
  isLoading: boolean;
}

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  icon ? : string;
  folder ? : string;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  timestamp: number;
  visitCount: number;
}

export interface BrowserSettings {
  theme: 'light' | 'dark' | 'auto';
  homePage: string;
  searchEngine: 'google' | 'bing' | 'duckduckgo';
  showBookmarksBar: boolean;
  enableHistory: boolean;
}

export interface BrowserData {
  bookmarks: Bookmark[];
  history: HistoryItem[];
  settings: BrowserSettings;
}
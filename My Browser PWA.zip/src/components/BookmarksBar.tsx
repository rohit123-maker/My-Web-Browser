/**
 * @file Bookmarks Bar Component
 * @description Displays frequently used bookmarks below the address bar
 */

import { Bookmark } from '../types/browser';
import { Button } from './ui/button';

interface BookmarksBarProps {
  bookmarks: Bookmark[];
  onBookmarkClick: (url: string) => void;
  visible: boolean;
}

/**
 * Bookmarks bar component for quick access to favorite sites
 */
export function BookmarksBar({ bookmarks, onBookmarkClick, visible }: BookmarksBarProps) {
  if (!visible || bookmarks.length === 0) return null;
  
  return (
    <div className="bg-gray-50 border-b border-gray-200 px-2 py-1">
      <div className="flex items-center gap-1 overflow-x-auto">
        {bookmarks.map((bookmark) => (
          <Button
            key={bookmark.id}
            variant="ghost"
            size="sm"
            onClick={() => onBookmarkClick(bookmark.url)}
            className="h-7 px-2 text-xs font-normal bg-transparent hover:bg-white"
          >
            {bookmark.title}
          </Button>
        ))}
      </div>
    </div>
  );
}
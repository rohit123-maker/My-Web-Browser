/**
 * @file Settings Modal Component
 * @description Browser settings and configuration interface
 */

import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Settings, Bookmark, History, Home, Moon, Sun, Monitor } from 'lucide-react';
import { BrowserSettings, HistoryItem, Bookmark as BookmarkType } from '../types/browser';

interface SettingsModalProps {
  settings: BrowserSettings;
  bookmarks: BookmarkType[];
  history: HistoryItem[];
  onSettingsUpdate: (settings: Partial < BrowserSettings > ) => void;
  onBookmarkRemove: (bookmarkId: string) => void;
  onHistoryClear: () => void;
  onBookmarkClick: (url: string) => void;
}

/**
 * Settings modal with tabs for different configuration sections
 */
export function SettingsModal({
  settings,
  bookmarks,
  history,
  onSettingsUpdate,
  onBookmarkRemove,
  onHistoryClear,
  onBookmarkClick
}: SettingsModalProps) {
  const [activeTab, setActiveTab] = useState < 'general' | 'bookmarks' | 'history' > ('general');
  const [homePage, setHomePage] = useState(settings.homePage);
  
  const handleHomePageSave = () => {
    onSettingsUpdate({ homePage });
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" className="bg-transparent h-8 w-8">
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>Browser Settings</DialogTitle>
        </DialogHeader>
        
        {/* Tab Navigation */}
        <div className="flex border-b">
          <Button
            variant="ghost"
            onClick={() => setActiveTab('general')}
            className={`rounded-none border-b-2 ${
              activeTab === 'general' 
                ? 'border-blue-500 text-blue-600' 
                : 'border-transparent'
            }`}
          >
            <Settings className="h-4 w-4 mr-2" />
            General
          </Button>
          <Button
            variant="ghost"
            onClick={() => setActiveTab('bookmarks')}
            className={`rounded-none border-b-2 ${
              activeTab === 'bookmarks' 
                ? 'border-blue-500 text-blue-600' 
                : 'border-transparent'
            }`}
          >
            <Bookmark className="h-4 w-4 mr-2" />
            Bookmarks
          </Button>
          <Button
            variant="ghost"
            onClick={() => setActiveTab('history')}
            className={`rounded-none border-b-2 ${
              activeTab === 'history' 
                ? 'border-blue-500 text-blue-600' 
                : 'border-transparent'
            }`}
          >
            <History className="h-4 w-4 mr-2" />
            History
          </Button>
        </div>

        {/* Tab Content */}
        <div className="overflow-y-auto max-h-96">
          {activeTab === 'general' && (
            <div className="space-y-4 p-4">
              {/* Theme Settings */}
              <div>
                <Label htmlFor="theme">Theme</Label>
                <Select
                  value={settings.theme}
                  onValueChange={(value: BrowserSettings['theme']) => 
                    onSettingsUpdate({ theme: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">
                      <div className="flex items-center gap-2">
                        <Sun className="h-4 w-4" />
                        Light
                      </div>
                    </SelectItem>
                    <SelectItem value="dark">
                      <div className="flex items-center gap-2">
                        <Moon className="h-4 w-4" />
                        Dark
                      </div>
                    </SelectItem>
                    <SelectItem value="auto">
                      <div className="flex items-center gap-2">
                        <Monitor className="h-4 w-4" />
                        System
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Home Page Settings */}
              <div>
                <Label htmlFor="homepage">Home Page</Label>
                <div className="flex gap-2">
                  <Input
                    value={homePage}
                    onChange={(e) => setHomePage(e.target.value)}
                    placeholder="Enter homepage URL"
                  />
                  <Button onClick={handleHomePageSave}>Save</Button>
                </div>
              </div>

              {/* Search Engine Settings */}
              <div>
                <Label htmlFor="search-engine">Search Engine</Label>
                <Select
                  value={settings.searchEngine}
                  onValueChange={(value: BrowserSettings['searchEngine']) => 
                    onSettingsUpdate({ searchEngine: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="google">Google</SelectItem>
                    <SelectItem value="bing">Bing</SelectItem>
                    <SelectItem value="duckduckgo">DuckDuckGo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Toggle Settings */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="bookmarks-bar">Show Bookmarks Bar</Label>
                  <Switch
                    checked={settings.showBookmarksBar}
                    onCheckedChange={(checked) => 
                      onSettingsUpdate({ showBookmarksBar: checked })
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="history">Enable History</Label>
                  <Switch
                    checked={settings.enableHistory}
                    onCheckedChange={(checked) => 
                      onSettingsUpdate({ enableHistory: checked })
                    }
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'bookmarks' && (
            <div className="p-4">
              {bookmarks.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <Bookmark className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No bookmarks yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {bookmarks.map((bookmark) => (
                    <div key={bookmark.id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                      <Button
                        variant="ghost"
                        className="justify-start flex-1 h-auto p-2"
                        onClick={() => onBookmarkClick(bookmark.url)}
                      >
                        <span className="truncate">{bookmark.title}</span>
                        <span className="text-gray-500 text-xs ml-2 truncate">{bookmark.url}</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onBookmarkRemove(bookmark.id)}
                        className="h-8 w-8 text-red-500 hover:text-red-700"
                      >
                        ×
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold">Browsing History</h3>
                <Button variant="outline" size="sm" onClick={onHistoryClear} className="bg-transparent">
                  Clear History
                </Button>
              </div>
              
              {history.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <History className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No browsing history</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {history.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                      <Button
                        variant="ghost"
                        className="justify-start flex-1 h-auto p-2"
                        onClick={() => onBookmarkClick(item.url)}
                      >
                        <div className="text-left">
                          <div className="font-medium truncate">{item.title}</div>
                          <div className="text-gray-500 text-xs truncate">{item.url}</div>
                          <div className="text-gray-400 text-xs">
                            {new Date(item.timestamp).toLocaleString()}
                          </div>
                        </div>
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
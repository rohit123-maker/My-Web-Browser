/**
 * @file Main Application Component
 * @description Sets up routing and PWA service worker
 */

import { HashRouter, Route, Routes } from 'react-router';
import Home from './pages/Home';
import { useEffect } from 'react';

export default function App() {
  /**
   * Register service worker for PWA functionality
   */
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('SW registered: ', registration);
        })
        .catch((registrationError) => {
          console.log('SW registration failed: ', registrationError);
        });
    }
  }, []);

  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
    </HashRouter>
  );
}

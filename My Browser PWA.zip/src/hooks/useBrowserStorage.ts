/**
 * @file Browser Storage Hook
 * @description Custom hook for managing browser data persistence
 */

import { useState, useEffect } from 'react';
import { BrowserData, Bookmark, HistoryItem, BrowserSettings } from '../types/browser';

const STORAGE_KEY = 'my-browser-data';

const defaultSettings: BrowserSettings = {
  theme: 'light',
  homePage: 'about:blank',
  searchEngine: 'google',
  showBookmarksBar: true,
  enableHistory: true
};

const defaultData: BrowserData = {
  bookmarks: [
    { id: '1', title: 'Google', url: 'https://www.google.com' },
    { id: '2', title: 'YouTube', url: 'https://www.youtube.com' },
    { id: '3', title: 'GitHub', url: 'https://www.github.com' },
    { id: '4', title: 'Wikipedia', url: 'https://www.wikipedia.org' }
  ],
  history: [],
  settings: defaultSettings
};

/**
 * Custom hook for managing browser data storage
 */
export function useBrowserStorage() {
  const [data, setData] = useState < BrowserData > (defaultData);
  const [isLoaded, setIsLoaded] = useState(false);
  
  /**
   * Load data from localStorage on mount
   */
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setData({ ...defaultData, ...parsed });
      }
      setIsLoaded(true);
    } catch (error) {
      console.error('Failed to load browser data:', error);
      setIsLoaded(true);
    }
  }, []);
  
  /**
   * Save data to localStorage whenever it changes
   */
  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      } catch (error) {
        console.error('Failed to save browser data:', error);
      }
    }
  }, [data, isLoaded]);
  
  /**
   * Add a bookmark
   */
  const addBookmark = (bookmark: Omit < Bookmark, 'id' > ) => {
    const newBookmark: Bookmark = {
      ...bookmark,
      id: Date.now().toString()
    };
    setData(prev => ({
      ...prev,
      bookmarks: [...prev.bookmarks, newBookmark]
    }));
  };
  
  /**
   * Remove a bookmark
   */
  const removeBookmark = (bookmarkId: string) => {
    setData(prev => ({
      ...prev,
      bookmarks: prev.bookmarks.filter(b => b.id !== bookmarkId)
    }));
  };
  
  /**
   * Add history item
   */
  const addHistory = (title: string, url: string) => {
    if (!data.settings.enableHistory) return;
    
    const existing = data.history.find(item => item.url === url);
    const timestamp = Date.now();
    
    if (existing) {
      // Update existing history item
      setData(prev => ({
        ...prev,
        history: prev.history.map(item =>
          item.url === url ?
          { ...item, timestamp, visitCount: item.visitCount + 1 } :
          item
        )
      }));
    } else {
      // Add new history item
      const newHistory: HistoryItem = {
        id: timestamp.toString(),
        title,
        url,
        timestamp,
        visitCount: 1
      };
      setData(prev => ({
        ...prev,
        history: [newHistory, ...prev.history].slice(0, 1000) // Keep last 1000 items
      }));
    }
  };
  
  /**
   * Clear history
   */
  const clearHistory = () => {
    setData(prev => ({
      ...prev,
      history: []
    }));
  };
  
  /**
   * Update settings
   */
  const updateSettings = (newSettings: Partial < BrowserSettings > ) => {
    setData(prev => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings }
    }));
  };
  
  /**
   * Apply theme to document
   */
  const applyTheme = (theme: BrowserSettings['theme']) => {
    const root = document.documentElement;
    
    if (theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  };
  
  return {
    data,
    isLoaded,
    addBookmark,
    removeBookmark,
    addHistory,
    clearHistory,
    updateSettings,
    applyTheme
  };
}